var express = require('express');
var router = express.Router();

// GET request for index (home page)
router.get('/', function(req, res) {
  res.render('index', { title: 'Home' });
});

// GET request for about me page
router.get('/aboutme', function(req, res) {
  res.render('aboutme', { title: 'About Me' });
});

// GET request for projects page
router.get('/projects', function(req, res) {
  res.render('projects', { title: 'Projects' });
});

// GET request for contact page
router.get('/contact', function(req, res) {
  res.render('contact', { title: 'Contact' });
});

module.exports = router;
